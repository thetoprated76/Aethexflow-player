﻿$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

function Banner($Text) { Write-Host "`n=== $Text ===" -ForegroundColor Cyan }
function Download-Reliable($Urls,$OutFile) {
  foreach ($Url in $Urls) {
    for ($Attempt=1; $Attempt -le 4; $Attempt++) {
      Write-Host "Download attempt $Attempt from $Url" -ForegroundColor DarkCyan
      & curl.exe --location --fail --retry 6 --retry-all-errors --retry-delay 3 --connect-timeout 30 --output $OutFile $Url
      if ($LASTEXITCODE -eq 0 -and (Test-Path $OutFile) -and (Get-Item $OutFile).Length -gt 0) { return }
      Start-Sleep -Seconds ([Math]::Min(15,$Attempt*3))
    }
    if (Test-Path $OutFile) { Remove-Item $OutFile -Force }
  }
  throw "Download failed: $OutFile"
}

function Refresh-Path {
  $machine = [Environment]::GetEnvironmentVariable('Path','Machine')
  $user = [Environment]::GetEnvironmentVariable('Path','User')
  $env:Path = "$machine;$user"
}
function Need($Command,$WingetId) {
  if (-not (Get-Command $Command -ErrorAction SilentlyContinue)) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { throw "winget is required to install $Command automatically." }
    Write-Host "Installing $WingetId..." -ForegroundColor Yellow
    & winget install --id $WingetId --exact --accept-package-agreements --accept-source-agreements --silent
    if ($LASTEXITCODE -ne 0) { throw "Installation failed: $WingetId" }
    Refresh-Path
  }
}

Banner 'Checking Windows build toolchain'
Need 'node' 'OpenJS.NodeJS.LTS'
Need 'python' 'Python.Python.3.11'
Need 'rustc' 'Rustlang.Rustup'
if (-not (Get-Command 7z -ErrorAction SilentlyContinue)) { Need '7z' '7zip.7zip' }

$VsWhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
$VcInstall = if (Test-Path $VsWhere) { & $VsWhere -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath | Select-Object -First 1 } else { $null }
if (-not $VcInstall) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { throw 'winget is required to install Microsoft C++ Build Tools.' }
  Write-Host 'Installing Microsoft Visual C++ Build Tools...' -ForegroundColor Yellow
  & winget install --id Microsoft.VisualStudio.2022.BuildTools --exact --accept-package-agreements --accept-source-agreements --force --override '--wait --quiet --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended'
  if ($LASTEXITCODE -ne 0) { throw 'Microsoft C++ Build Tools installation failed.' }
  Refresh-Path
}

Banner 'Preparing MPC-BE playback engine'
$MpcDir = Join-Path $Root 'src-tauri\resources\mpc-be'
$MpcExe = Join-Path $MpcDir 'mpc-be64.exe'
if (-not (Test-Path $MpcExe)) {
  $Release = Invoke-RestMethod -Headers @{ 'User-Agent' = 'AethexFlow-Builder' } -Uri 'https://api.github.com/repos/Aleksoid1978/MPC-BE/releases/latest'
  $Asset = $Release.assets | Where-Object { $_.name -match 'x64.*\.7z$' -and $_.name -notmatch 'symbols' } | Select-Object -First 1
  if (-not $Asset) { throw 'Could not locate the latest MPC-BE x64 portable archive.' }
  $MpcArchive = Join-Path $env:TEMP $Asset.name
  $MpcTemp = Join-Path $env:TEMP 'aethexflow-mpc-be'
  Download-Reliable @($Asset.browser_download_url) $MpcArchive
  if (Test-Path $MpcTemp) { Remove-Item $MpcTemp -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $MpcTemp | Out-Null
  & 7z x $MpcArchive "-o$MpcTemp" -y | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'MPC-BE archive extraction failed.' }
  $FoundMpc = Get-ChildItem $MpcTemp -Recurse -Filter 'mpc-be64.exe' | Select-Object -First 1
  if (-not $FoundMpc) { throw 'MPC-BE archive did not contain mpc-be64.exe.' }
  if (Test-Path $MpcDir) { Remove-Item $MpcDir -Recurse -Force }
  Copy-Item $FoundMpc.Directory.FullName $MpcDir -Recurse -Force
}

Banner 'Static release validation'
python tools/validate_release.py
if ($LASTEXITCODE -ne 0) { throw 'Base release preflight failed.' }
python tools/validate_inno_release.py
if ($LASTEXITCODE -ne 0) { throw 'Inno release preflight failed.' }

Banner 'Preparing bundled runtime' 
# Reuse the hardened existing builder only through its runtime preparation logic by reproducing the required steps here.
$Runtime = Join-Path $Root 'runtime'
$PythonDir = Join-Path $Runtime 'python'
$FfmpegDir = Join-Path $Runtime 'ffmpeg\bin'
$ModelDir = Join-Path $Runtime 'models\whisper-small'
New-Item -ItemType Directory -Force -Path $PythonDir,$FfmpegDir,(Split-Path $ModelDir) | Out-Null

$PyExe = Join-Path $PythonDir 'python.exe'
if (-not (Test-Path $PyExe)) {
  $PyZip = Join-Path $env:TEMP 'aethexflow-python-3.11.9.zip'
  Download-Reliable @('https://www.python.org/ftp/python/3.11.9/python-3.11.9-embed-amd64.zip') $PyZip
  Expand-Archive $PyZip -DestinationPath $PythonDir -Force
  $Pth = Join-Path $PythonDir 'python311._pth'
  (Get-Content $Pth) -replace '^#import site$','import site' | Set-Content $Pth -Encoding ASCII
  Download-Reliable @('https://bootstrap.pypa.io/get-pip.py') (Join-Path $PythonDir 'get-pip.py')
  & $PyExe (Join-Path $PythonDir 'get-pip.py') --no-warn-script-location
}
& $PyExe -m pip install --upgrade pip --no-warn-script-location
& $PyExe -m pip install -r (Join-Path $Root 'ai\requirements.txt') --no-warn-script-location
if ($LASTEXITCODE -ne 0) { throw 'AI dependency installation failed.' }
& $PyExe -m pip install resemblyzer==0.1.4 --no-deps --no-warn-script-location
if ($LASTEXITCODE -ne 0) { throw 'Resemblyzer installation failed.' }
& $PyExe -c "import webrtcvad, torch, librosa, sklearn, soundfile, win32com.client; from resemblyzer import VoiceEncoder; print('AI runtime verified')"
if ($LASTEXITCODE -ne 0) { throw 'AI runtime verification failed.' }

if (-not (Test-Path (Join-Path $FfmpegDir 'ffmpeg.exe'))) {
  $FfZip = Join-Path $env:TEMP 'aethexflow-ffmpeg.zip'
  $FfTemp = Join-Path $env:TEMP 'aethexflow-ffmpeg-unpack'
  Download-Reliable @(
    'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip',
    'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip'
  ) $FfZip
  if (Test-Path $FfTemp) { Remove-Item $FfTemp -Recurse -Force }
  Expand-Archive $FfZip -DestinationPath $FfTemp -Force
  $Found = Get-ChildItem $FfTemp -Recurse -Filter ffmpeg.exe | Select-Object -First 1
  if (-not $Found) { throw 'FFmpeg archive did not contain ffmpeg.exe.' }
  Copy-Item (Join-Path $Found.Directory.FullName 'ffmpeg.exe') $FfmpegDir -Force
  Copy-Item (Join-Path $Found.Directory.FullName 'ffprobe.exe') $FfmpegDir -Force
  $License = Get-ChildItem $FfTemp -Recurse -Filter 'LICENSE*' | Select-Object -First 1
  if ($License) { Copy-Item $License.FullName (Join-Path $FfmpegDir 'FFMPEG-LICENSE.txt') -Force }
}

if (-not (Test-Path (Join-Path $ModelDir 'model.bin'))) {
  New-Item -ItemType Directory -Force -Path $ModelDir | Out-Null
  & $PyExe -c "from huggingface_hub import snapshot_download; snapshot_download('Systran/faster-whisper-small', local_dir=r'$ModelDir')"
  if ($LASTEXITCODE -ne 0) { throw 'Whisper model download failed.' }
}

Banner 'Building native Windows application'
if (Test-Path (Join-Path $Root 'package-lock.json')) { npm ci } else { npm install }
if ($LASTEXITCODE -ne 0) { throw 'npm dependency installation failed.' }
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed.' }
npm run tauri:build -- --no-bundle
if ($LASTEXITCODE -ne 0) { throw 'Native Tauri executable build failed.' }

$Exe = Join-Path $Root 'src-tauri\target\release\aethexflow-player.exe'
if (-not (Test-Path $Exe)) { throw 'Native executable missing after successful Tauri build.' }

Banner 'Staging single-file offline installer payload'
$Stage = Join-Path $Root 'stage'
$Release = Join-Path $Root 'release'
if (Test-Path $Stage) { Remove-Item $Stage -Recurse -Force }
if (Test-Path $Release) { Remove-Item $Release -Recurse -Force }
New-Item -ItemType Directory -Force -Path $Stage,$Release,(Join-Path $Stage 'redist') | Out-Null
Copy-Item $Exe (Join-Path $Stage 'aethexflow-player.exe') -Force
Copy-Item (Join-Path $Root 'src-tauri\resources\mpc-be') (Join-Path $Stage 'mpc-be') -Recurse -Force
Copy-Item $PythonDir (Join-Path $Stage 'python') -Recurse -Force
Copy-Item (Join-Path $Runtime 'ffmpeg') (Join-Path $Stage 'ffmpeg') -Recurse -Force
Copy-Item (Join-Path $Runtime 'models') (Join-Path $Stage 'models') -Recurse -Force
New-Item -ItemType Directory -Force -Path (Join-Path $Stage 'ai') | Out-Null
Copy-Item (Join-Path $Root 'ai\dub_worker.py') (Join-Path $Stage 'ai\dub_worker.py') -Force

$Notice = @'
AethexFlow Player bundles third-party components. Their respective licenses apply.
MPC-BE license/notices are included in the bundled mpc-be directory.
FFmpeg license information is included in the bundled ffmpeg directory when supplied by the build archive.
Python and Python packages retain their own upstream licenses.
Microsoft Edge WebView2 Runtime is distributed under Microsoft's applicable WebView2 terms.
'@
$Notice | Set-Content (Join-Path $Stage 'THIRD-PARTY-NOTICES.txt') -Encoding UTF8

Banner 'Bundling WebView2 for offline installation'
$WebView = Join-Path $Stage 'redist\MicrosoftEdgeWebView2RuntimeInstallerX64.exe'
Download-Reliable @('https://go.microsoft.com/fwlink/p/?LinkId=2124703') $WebView
$WebViewSize = (Get-Item $WebView).Length
if ($WebViewSize -lt 50000000) {
  throw "WebView2 download is only $WebViewSize bytes; refusing to label the installer offline because this appears to be a bootstrapper rather than the standalone runtime."
}

Banner 'Installing Inno Setup compiler on build runner'
$ISCC = Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'
if (-not (Test-Path $ISCC)) {
  if (Get-Command choco -ErrorAction SilentlyContinue) {
    choco install innosetup -y --no-progress
  } elseif (Get-Command winget -ErrorAction SilentlyContinue) {
    winget install --id JRSoftware.InnoSetup --exact --accept-package-agreements --accept-source-agreements --silent
  } else {
    throw 'Neither Chocolatey nor winget is available to install Inno Setup.'
  }
}
if (-not (Test-Path $ISCC)) { throw 'Inno Setup compiler was not found after installation.' }

Banner 'Compiling AethexFlow Player offline Setup.exe'
& $ISCC (Join-Path $Root 'installer\AethexFlowPlayer.iss')
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup compilation failed.' }
$Setup = Join-Path $Release 'AethexFlow-Player-Setup.exe'
if (-not (Test-Path $Setup)) { throw 'Inno Setup reported success but Setup.exe was not produced.' }

$Hash = (Get-FileHash $Setup -Algorithm SHA256).Hash.ToLowerInvariant()
"$Hash  AethexFlow-Player-Setup.exe" | Set-Content (Join-Path $Release 'SHA256SUMS.txt') -Encoding ASCII
@"
AETHEXFLOW PLAYER WINDOWS RELEASE
Version: 3.0.0
Primary artifact: AethexFlow-Player-Setup.exe
Packaging: Inno Setup single-file offline installer
Includes: app executable, MPC-BE, portable Python AI runtime, FFmpeg/FFprobe, Whisper model, WebView2 standalone runtime
Verification state after CI build: BUILT (installation must still be executed on Windows before INSTALLER VERIFIED)
"@ | Set-Content (Join-Path $Release 'BUILD-STATUS.txt') -Encoding UTF8

Banner 'BUILD COMPLETE'
Write-Host "Setup: $Setup" -ForegroundColor Green
Write-Host "SHA256: $Hash" -ForegroundColor Green
