import argparse, json, os, subprocess, sys, tempfile, shutil, math
from pathlib import Path


def run(cmd):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode:
        raise RuntimeError(p.stderr[-5000:] or "Command failed")
    return p


def ffmpeg_bin():
    p = os.environ.get("AETHEXFLOW_FFMPEG")
    if p and Path(p).exists(): return p
    return shutil.which("ffmpeg") or "ffmpeg"


def extract_audio(video, wav):
    run([ffmpeg_bin(), "-y", "-i", video, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", wav])


def cosine(a,b):
    import numpy as np
    d = float(np.linalg.norm(a)*np.linalg.norm(b))
    return float(np.dot(a,b)/d) if d else 0.0


def analyze(video, model_name):
    from faster_whisper import WhisperModel
    from resemblyzer import VoiceEncoder, preprocess_wav
    import librosa, numpy as np

    with tempfile.TemporaryDirectory(prefix="aef_") as td:
        wav = str(Path(td)/"audio.wav")
        extract_audio(video, wav)
        bundled_model = Path(__file__).resolve().parent.parent / "models" / "whisper-small"
        selected_model = str(bundled_model) if bundled_model.exists() else model_name
        try:
            model = WhisperModel(selected_model, device="cuda", compute_type="float16")
        except Exception:
            model = WhisperModel(selected_model, device="cpu", compute_type="int8")
        segs, info = model.transcribe(wav, vad_filter=True, word_timestamps=False, beam_size=5)
        segs = list(segs)
        audio, sr = librosa.load(wav, sr=16000, mono=True)
        encoder = VoiceEncoder()
        profiles=[]
        result=[]
        for idx,s in enumerate(segs):
            start=float(s.start); end=float(s.end); text=s.text.strip()
            if not text: continue
            a=max(0,int(start*sr)); b=min(len(audio),int(end*sr)); clip=audio[a:b]
            speaker="Speaker 01"; conf=0.55
            if len(clip)>int(.55*sr):
                try:
                    emb=encoder.embed_utterance(preprocess_wav(clip, source_sr=sr))
                    sims=[cosine(emb,p[1]) for p in profiles]
                    if sims and max(sims)>=0.67:
                        j=int(np.argmax(sims)); speaker=profiles[j][0]; conf=max(.55,min(.98,float(max(sims))))
                    elif len(profiles)<8:
                        speaker=f"Speaker {len(profiles)+1:02d}"; profiles.append((speaker,emb)); conf=.65
                    else:
                        j=int(np.argmax(sims)); speaker=profiles[j][0]; conf=max(.55,min(.95,float(max(sims))))
                except Exception:
                    pass
            gender="Unknown"; gconf=0.0
            if len(clip)>int(.8*sr):
                try:
                    f0,_,_=librosa.pyin(clip, fmin=70, fmax=350, sr=sr)
                    vals=f0[np.isfinite(f0)]
                    if len(vals)>8:
                        med=float(np.median(vals))
                        if med>=175: gender="Female"
                        elif med<=155: gender="Male"
                        else: gender="Unknown"
                        gconf=min(.97,max(.52,1-abs(med-165)/140))
                except Exception: pass
            result.append({"index":idx,"start":start,"end":end,"text":text,"speaker":speaker,"gender":gender,"confidence":round(float(min(conf,gconf or conf)),3)})
        speakers={}
        for x in result:
            sid=x["speaker"]
            if sid not in speakers: speakers[sid]={"id":sid,"gender":x["gender"],"confidence":x["confidence"],"voice":""}
            elif speakers[sid]["gender"]=="Unknown" and x["gender"]!="Unknown": speakers[sid]["gender"]=x["gender"]
        return {"language":getattr(info,"language",None),"segments":result,"speakers":list(speakers.values())}


def sapi_tts(text, voice, out):
    import win32com.client
    from win32com.client import constants
    voice_engine=win32com.client.Dispatch("SAPI.SpVoice")
    voices=voice_engine.GetVoices()
    chosen=None
    for i in range(voices.Count):
        v=voices.Item(i)
        if v.GetDescription().lower()==voice.lower() or voice.lower() in v.GetDescription().lower(): chosen=v; break
    if chosen is not None: voice_engine.Voice=chosen
    stream=win32com.client.Dispatch("SAPI.SpFileStream")
    stream.Open(str(out), 3, False)  # SSFMCreateForWrite
    voice_engine.AudioOutputStream=stream
    voice_engine.Speak(text)
    stream.Close()


def build_dub(video, analysis, output_wav):
    if os.name != "nt": raise RuntimeError("Windows SAPI dubbing is supported on Windows only")
    import numpy as np
    with tempfile.TemporaryDirectory(prefix="aef_tts_") as td:
        cues=[]
        speaker_list=analysis.get("speakers",[])
        voice_map={v.get("id"):v.get("voice") for v in speaker_list}
        male=next((v.get("voice") for v in speaker_list if v.get("gender","").lower().startswith("male") and v.get("voice")),None)
        female=next((v.get("voice") for v in speaker_list if v.get("gender","").lower().startswith("female") and v.get("voice")),None)
        for n,seg in enumerate(analysis["segments"]):
            voice=voice_map.get(seg["speaker"]) or (female if seg["gender"]=="Female" else male)
            if not voice: continue
            p=Path(td)/f"c{n:05d}.wav"
            try: sapi_tts(seg["text"],voice,p)
            except Exception: continue
            cues.append((p,float(seg["start"]),float(seg["end"])))
        if not cues: raise RuntimeError("No TTS cues were generated. Select at least one Windows voice.")
        # Mix delayed cues into one timeline. FFmpeg keeps each cue at its original timestamp.
        cmd=[ffmpeg_bin(),"-y","-f","lavfi","-i",f"anullsrc=r=24000:cl=stereo:d={max(x[2] for x in cues)+1}"]
        for p,_,_ in cues: cmd += ["-i",str(p)]
        filters=["[0:a]anull[a0]"]; labels=["[a0]"]
        for j,(_,st,_) in enumerate(cues,1):
            ms=max(0,int(st*1000)); lab=f"a{j}"
            filters.append(f"[{j}:a]adelay={ms}|{ms},volume=1[{lab}]"); labels.append(f"[{lab}]")
        filters.append("".join(labels)+f"amix=inputs={len(labels)}:duration=longest:normalize=0[out]")
        cmd += ["-filter_complex",";".join(filters),"-map","[out]","-c:a","pcm_s16le",output_wav]
        run(cmd)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--mode",choices=["analyze","dub"],required=True); ap.add_argument("--video",required=True); ap.add_argument("--output",required=True); ap.add_argument("--model",default=os.environ.get("AETHEXFLOW_WHISPER_MODEL","small")); ap.add_argument("--analysis",default="")
    a=ap.parse_args()
    if a.mode=="analyze": print(json.dumps(analyze(a.video,a.model),ensure_ascii=False))
    else:
        data=json.loads(Path(a.analysis).read_text(encoding="utf-8")); build_dub(a.video,data,a.output); print(json.dumps({"output":a.output}))
if __name__=="__main__":
    try: main()
    except Exception as e: print(json.dumps({"error":str(e)})); sys.exit(1)
