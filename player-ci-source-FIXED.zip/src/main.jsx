import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { invoke } from "@tauri-apps/api/core";
import { open, save } from "@tauri-apps/plugin-dialog";
import "./styles.css";
import "./license.css";

const VIDEO =
  /\.(mp4|mkv|webm|avi|mov|m4v|wmv|flv|ts|m2ts|3gp|mpeg|mpg|vob|ogv)$/i;
const AUDIO = /\.(mp3|flac|wav|aac|m4a|ogg|opus|wma)$/i;
const MEDIA = (p) => VIDEO.test(p) || AUDIO.test(p);
const uid = () =>
  globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`;
const nameOf = (p) => p.split(/[\\/]/).pop();
const fmt = (s) => {
  s = Math.max(0, Number(s) || 0);
  const h = Math.floor(s / 3600),
    m = Math.floor((s % 3600) / 60),
    x = Math.floor(s % 60);
  return h
    ? `${h}:${String(m).padStart(2, "0")}:${String(x).padStart(2, "0")}`
    : `${m}:${String(x).padStart(2, "0")}`;
};
const load = (k, d) => {
  try {
    return JSON.parse(localStorage.getItem(k)) ?? d;
  } catch {
    return d;
  }
};

function App() {
  const [files, setFiles] = useState(() => load("aef.library", []));
  const [active, setActive] = useState(-1),
    [playing, setPlaying] = useState(false),
    [embedded, setEmbedded] = useState(false);
  const [voices, setVoices] = useState([]),
    [tracks, setTracks] = useState([]),
    [speakers, setSpeakers] = useState([]),
    [analysis, setAnalysis] = useState(null);
  const [busy, setBusy] = useState(false),
    [panel, setPanel] = useState("player"),
    [msg, setMsg] = useState("Ready");
  const [speed, setSpeed] = useState(1),
    [time, setTime] = useState(0),
    [dur, setDur] = useState(0),
    [volume, setVolumeState] = useState(() => load("aef.volume", 80));
  const [query, setQuery] = useState(""),
    [repeat, setRepeat] = useState("off"),
    [shuffle, setShuffle] = useState(false),
    [info, setInfo] = useState(null);
  const [license, setLicense] = useState({
      paid: false,
      freeUsed: 0,
      freeRemaining: 5,
      status: "checking",
    }),
    [licenseKey, setLicenseKey] = useState(""),
    [licenseBusy, setLicenseBusy] = useState(false);
  const [settings, setSettings] = useState(() =>
    load("aef.settings", {
      autoplay: true,
      remember: true,
      hardware: true,
      alwaysOnTop: false,
    }),
  );
  const videoRef = useRef(null);
  const current = files[active];
  const visible = useMemo(
    () =>
      files
        .map((f, i) => ({ ...f, index: i }))
        .filter((f) => f.name.toLowerCase().includes(query.toLowerCase())),
    [files, query],
  );

  useEffect(() => {
    localStorage.setItem("aef.library", JSON.stringify(files));
  }, [files]);
  useEffect(() => {
    localStorage.setItem("aef.volume", JSON.stringify(volume));
  }, [volume]);
  useEffect(() => {
    localStorage.setItem("aef.settings", JSON.stringify(settings));
    invoke("set_always_on_top", { value: settings.alwaysOnTop }).catch(
      () => {},
    );
  }, [settings]);
  useEffect(() => {
    invoke("installed_voices")
      .then(setVoices)
      .catch(() => {});
    invoke("locate_mpc")
      .then(() => setMsg("Playback engine ready"))
      .catch((e) => setMsg(String(e)));
    invoke("license_status")
      .then(setLicense)
      .catch(() => setLicense((x) => ({ ...x, status: "offline" })));
  }, []);
  useEffect(() => {
    const key = (e) => {
      if (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
      if (e.code === "Space") {
        e.preventDefault();
        togglePlay();
      }
      if (e.code === "ArrowRight") seekBy(10);
      if (e.code === "ArrowLeft") seekBy(-10);
      if (e.code === "ArrowUp") setVolume(Math.min(100, volume + 5));
      if (e.code === "ArrowDown") setVolume(Math.max(0, volume - 5));
      if (e.key.toLowerCase() === "f") fullscreen();
      if (e.key.toLowerCase() === "m") mute();
      if (e.key.toLowerCase() === "o" && e.ctrlKey) {
        e.preventDefault();
        addFiles();
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  });

  const addPaths = (paths) => {
    const incoming = paths
      .filter(MEDIA)
      .filter((p) => !files.some((f) => f.path === p))
      .map((p) => ({
        id: uid(),
        name: nameOf(p),
        path: p,
        played: 0,
        duration: 0,
        added: Date.now(),
      }));
    if (!incoming.length) {
      setMsg("No supported media found");
      return;
    }
    setFiles((x) => [...x, ...incoming]);
    setMsg(`${incoming.length} item${incoming.length > 1 ? "s" : ""} added`);
    if (active < 0)
      setTimeout(() => openFile(files.length, [...files, ...incoming]), 0);
  };
  const addFiles = async () => {
    try {
      const p = await open({
        multiple: true,
        filters: [
          {
            name: "Media",
            extensions: [
              "mp4",
              "mkv",
              "webm",
              "avi",
              "mov",
              "m4v",
              "wmv",
              "flv",
              "ts",
              "m2ts",
              "3gp",
              "mpeg",
              "mpg",
              "vob",
              "ogv",
              "mp3",
              "flac",
              "wav",
              "aac",
              "m4a",
              "ogg",
              "opus",
              "wma",
            ],
          },
        ],
      });
      if (p) addPaths(Array.isArray(p) ? p : [p]);
    } catch (e) {
      setMsg(String(e));
    }
  };
  const addFolder = async () => {
    try {
      const p = await open({ directory: true, multiple: false });
      if (p) {
        setBusy(true);
        setMsg("Scanning folder…");
        const paths = await invoke("scan_media_folder", { folderPath: p });
        addPaths(paths);
      }
    } catch (e) {
      setMsg(String(e));
    } finally {
      setBusy(false);
    }
  };
  const layoutMpc = () => {
    if (!embedded || !videoRef.current) return;
    const r = videoRef.current.getBoundingClientRect();
    invoke("resize_mpc", {
      x: Math.round(r.left),
      y: Math.round(r.top),
      w: Math.max(10, Math.round(r.width)),
      h: Math.max(10, Math.round(r.height)),
    }).catch(() => {});
  };
  useEffect(() => {
    window.addEventListener("resize", layoutMpc);
    return () => window.removeEventListener("resize", layoutMpc);
  }, [embedded]);
  const openFile = async (i, source = files) => {
    const f = source[i];
    if (!f) return;
    try {
      setActive(i);
      setEmbedded(false);
      setPlaying(true);
      setInfo(null);
      setTime(settings.remember ? f.played || 0 : 0);
      setDur(f.duration || 0);
      setMsg(`Opening ${f.name}…`);
      const p = await invoke("launch_mpc", { filePath: f.path });
      const [t, meta] = await Promise.all([
        invoke("ffprobe_tracks", { filePath: p }).catch(() => []),
        invoke("media_info", { filePath: p }).catch(() => null),
      ]);
      setTracks(t);
      setInfo(meta);
      if (meta?.duration) {
        setDur(meta.duration);
        setFiles((x) =>
          x.map((z, j) => (j === i ? { ...z, duration: meta.duration } : z)),
        );
      }
      setTimeout(async () => {
        try {
          await invoke("embed_mpc", { x: 0, y: 0, w: 100, h: 100 });
          setEmbedded(true);
          setTimeout(layoutMpc, 100);
          setVolume(volume);
          if (settings.remember && f.played > 3)
            invoke("seek_to", { seconds: f.played }).catch(() => {});
          setMsg("Playing");
        } catch (e) {
          setMsg(`Player: ${e}`);
        }
      }, 350);
    } catch (e) {
      setPlaying(false);
      setMsg(String(e));
    }
  };
  const command = (code, param = "") =>
    invoke("mpc_command", { code, param }).catch((e) => setMsg(String(e)));
  const togglePlay = () => {
    if (!current) return addFiles();
    command(0xa0000003);
    setPlaying((x) => !x);
  };
  const seekBy = (n) => {
    if (!current) return;
    const v = Math.max(0, Math.min(dur || Infinity, time + n));
    setTime(v);
    invoke("seek_to", { seconds: v }).catch(() => {});
  };
  const seekTo = (v) => {
    setTime(v);
    invoke("seek_to", { seconds: v }).catch(() => {});
  };
  const setVolume = (v) => {
    setVolumeState(v);
    invoke("set_volume", { volume: v }).catch(() => {});
  };
  const mute = () => {
    command(0xa0000005);
    setMsg(volume ? "Muted" : "Audio on");
  };
  const fullscreen = () =>
    invoke("toggle_fullscreen").catch((e) => setMsg(String(e)));
  const next = () => {
    if (!files.length) return;
    let n = shuffle
      ? Math.floor(Math.random() * files.length)
      : (active + 1) % files.length;
    openFile(n);
  };
  const previous = () => openFile(active <= 0 ? files.length - 1 : active - 1);
  const remove = (i) => {
    const was = i === active;
    setFiles((x) => x.filter((_, j) => j !== i));
    if (was) {
      invoke("stop_mpc").catch(() => {});
      setActive(-1);
      setEmbedded(false);
      setPlaying(false);
      setInfo(null);
    } else if (i < active) setActive((x) => x - 1);
  };
  const clear = () => {
    invoke("stop_mpc").catch(() => {});
    setFiles([]);
    setActive(-1);
    setEmbedded(false);
    setPlaying(false);
    setInfo(null);
    setMsg("Library cleared");
  };
  const subtitle = async () => {
    try {
      const p = await open({
        multiple: false,
        filters: [
          {
            name: "Subtitles",
            extensions: ["srt", "vtt", "ass", "ssa", "sub"],
          },
        ],
      });
      if (p) {
        await invoke("load_subtitle", { filePath: p });
        setMsg(`Subtitles loaded: ${nameOf(p)}`);
      }
    } catch (e) {
      setMsg(String(e));
    }
  };
  const screenshot = async () => {
    if (!current) return;
    try {
      const out = await save({
        defaultPath: `AethexFlow-${Date.now()}.png`,
        filters: [{ name: "PNG image", extensions: ["png"] }],
      });
      if (out) {
        await invoke("take_screenshot", { outputPath: out });
        setMsg(`Screenshot saved: ${nameOf(out)}`);
      }
    } catch (e) {
      setMsg(String(e));
    }
  };
  const reveal = () =>
    current &&
    invoke("reveal_file", { filePath: current.path }).catch((e) =>
      setMsg(String(e)),
    );
  const analyze = async () => {
    if (!current) return;
    setBusy(true);
    setMsg("Analyzing speech and speakers locally…");
    try {
      const a = await invoke("analyze_speakers", { filePath: current.path });
      setAnalysis(a);
      setSpeakers(
        (a.speakers || []).map((s) => {
          const pool = voices.filter((v) =>
            String(v.gender)
              .toLowerCase()
              .startsWith(String(s.gender || "").toLowerCase()),
          );
          return { ...s, voice: (pool[0] || voices[0])?.name || "" };
        }),
      );
      setMsg(`Analysis ready • ${(a.segments || []).length} dialogue segments`);
    } catch (e) {
      setMsg(String(e));
    } finally {
      setBusy(false);
    }
  };
  const generateDub = async () => {
    if (!current || !analysis) return;
    setBusy(true);
    try {
      setMsg("Checking dubbing entitlement…");
      const auth = await invoke("authorize_dub");
      const out = await save({
        defaultPath:
          current.name.replace(/\.[^.]+$/, "") + "_AethexFlow_Dub.mkv",
        filters: [{ name: "Dual-audio video", extensions: ["mkv", "mp4"] }],
      });
      if (!out) {
        setMsg("Export cancelled — quota was not used");
        return;
      }
      const wav = out + ".aefdub.wav";
      setMsg("Generating synchronized dubbing…");
      await invoke("generate_dub", {
        filePath: current.path,
        analysis: { ...analysis, speakers },
        outputWav: wav,
        jobToken: auth.jobToken,
      });
      setMsg("Muxing original and dubbed audio…");
      await invoke("mux_dub", {
        video: current.path,
        dubAudio: wav,
        output: out,
      });
      const done = await invoke("complete_dub", { jobToken: auth.jobToken });
      setLicense((x) => ({
        ...x,
        ...done,
        status: done.paid ? "active" : "free",
      }));
      setMsg("Dual-audio video exported successfully");
    } catch (e) {
      setMsg(String(e));
      setPanel("dub");
    } finally {
      setBusy(false);
    }
  };
  const activate = async () => {
    if (!licenseKey.trim()) return;
    setLicenseBusy(true);
    setMsg("Activating Lemon Squeezy license…");
    try {
      const v = await invoke("activate_license", { licenseKey });
      setLicense((x) => ({ ...x, ...v }));
      setLicenseKey("");
      setMsg("AethexFlow Plus activated on this device");
    } catch (e) {
      setMsg(String(e));
    } finally {
      setLicenseBusy(false);
    }
  };
  const setting = (k, v) => setSettings((x) => ({ ...x, [k]: v }));

  return (
    <div className="app">
      <header>
        <div className="brand">
          <span className="mark">A</span>
          <div>
            <strong>AethexFlow</strong>
            <small>OFFLINE MEDIA PLAYER</small>
          </div>
        </div>
        <nav>
          <button
            className={panel === "player" ? "on" : ""}
            onClick={() => setPanel("player")}
          >
            Player
          </button>
          <button
            className={panel === "dub" ? "on" : ""}
            onClick={() => setPanel("dub")}
          >
            AI Dub
          </button>
          <button
            className={panel === "settings" ? "on" : ""}
            onClick={() => setPanel("settings")}
          >
            Settings
          </button>
        </nav>
        <div className="window-actions">
          <button title="Open files (Ctrl+O)" onClick={addFiles}>
            ＋ Open
          </button>
          <button title="Add a complete folder" onClick={addFolder}>
            ▣ Folder
          </button>
        </div>
      </header>
      <div className="body">
        <aside>
          <div className="library-head">
            <div>
              <b>PLAYLIST</b>
              <span>{files.length} items</span>
            </div>
            <button onClick={clear} disabled={!files.length}>
              Clear
            </button>
          </div>
          <div className="search">
            <span>⌕</span>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search playlist"
            />
          </div>
          <div className="files">
            {visible.map((f) => (
              <div
                className={"file " + (f.index === active ? "sel" : "")}
                key={f.id}
              >
                <button
                  className="file-main"
                  onDoubleClick={() => openFile(f.index)}
                  onClick={() => openFile(f.index)}
                >
                  <span className="thumb">
                    {VIDEO.test(f.path) ? "▶" : "♫"}
                  </span>
                  <span className="file-copy">
                    <b>{f.name}</b>
                    <small>
                      {f.duration
                        ? fmt(f.duration)
                        : VIDEO.test(f.path)
                          ? "VIDEO"
                          : "AUDIO"}
                      {f.played > 3 ? ` • Resume ${fmt(f.played)}` : ""}
                    </small>
                  </span>
                </button>
                <button
                  className="remove"
                  title="Remove"
                  onClick={() => remove(f.index)}
                >
                  ×
                </button>
              </div>
            ))}
            {!files.length && (
              <div className="empty">
                <div>＋</div>
                <b>Your playlist is empty</b>
                <span>
                  Open media files or scan a folder.
                  <br />
                  Everything plays locally.
                </span>
                <button onClick={addFiles}>OPEN MEDIA</button>
              </div>
            )}
          </div>
          <div className="side-foot">
            <button onClick={addFiles}>＋ Files</button>
            <button onClick={addFolder}>▣ Folder</button>
          </div>
        </aside>
        <main>
          <section
            className={"video " + (embedded ? "native-playing" : "")}
            ref={videoRef}
          >
            <div className="stage">
              <div className="bigA">A</div>
              <h1>{current?.name || "Your media. Your device."}</h1>
              <p>
                {current
                  ? "Preparing the offline playback engine…"
                  : "Private, fast playback without uploads or ads."}
              </p>
              {!current && (
                <div className="stage-buttons">
                  <button className="primary" onClick={addFiles}>
                    OPEN MEDIA
                  </button>
                  <button onClick={addFolder}>OPEN FOLDER</button>
                </div>
              )}
            </div>
            {current && <div className="media-badge">LOCAL PLAYBACK</div>}
          </section>
          <section className="controls">
            <input
              className="timeline"
              aria-label="Seek"
              type="range"
              min="0"
              max={dur || 100}
              value={Math.min(time, dur || 100)}
              onChange={(e) => seekTo(+e.target.value)}
            />
            <div className="times">
              <span>{fmt(time)}</span>
              <span>-{fmt(Math.max(0, dur - time))}</span>
            </div>
            <div className="control-row">
              <div className="control-side">
                <button title="Subtitles" onClick={subtitle}>
                  CC
                </button>
                <button title="Screenshot" onClick={screenshot}>
                  ▣
                </button>
                <button
                  title="Media information"
                  onClick={() => setPanel(panel === "info" ? "player" : "info")}
                >
                  ⓘ
                </button>
              </div>
              <div className="transport">
                <button title="Previous" onClick={previous}>
                  ┃◀
                </button>
                <button title="Back 10 seconds" onClick={() => seekBy(-10)}>
                  ↶<small>10</small>
                </button>
                <button
                  className="play"
                  title="Play / pause (Space)"
                  onClick={togglePlay}
                >
                  {playing ? "Ⅱ" : "▶"}
                </button>
                <button title="Forward 10 seconds" onClick={() => seekBy(10)}>
                  ↷<small>10</small>
                </button>
                <button title="Next" onClick={next}>
                  ▶┃
                </button>
              </div>
              <div className="control-side right">
                <button
                  className={shuffle ? "active" : ""}
                  title="Shuffle"
                  onClick={() => setShuffle((x) => !x)}
                >
                  ⤨
                </button>
                <button
                  title="Repeat"
                  className={repeat !== "off" ? "active" : ""}
                  onClick={() =>
                    setRepeat((x) =>
                      x === "off" ? "all" : x === "all" ? "one" : "off",
                    )
                  }
                >
                  {repeat === "one" ? "↻¹" : "↻"}
                </button>
                <button title="Mute (M)" onClick={mute}>
                  {volume === 0 ? "🔇" : "🔊"}
                </button>
                <input
                  aria-label="Volume"
                  className="volume"
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={(e) => setVolume(+e.target.value)}
                />
                <select
                  title="Playback speed"
                  value={speed}
                  onChange={(e) => {
                    const v = +e.target.value;
                    setSpeed(v);
                    invoke("set_speed", { speed: v }).catch(() => {});
                  }}
                >
                  {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((v) => (
                    <option key={v} value={v}>
                      {v}×
                    </option>
                  ))}
                </select>
                <button title="Fullscreen (F)" onClick={fullscreen}>
                  ⛶
                </button>
              </div>
            </div>
          </section>
          {panel === "info" && (
            <section className="drawer">
              <div className="drawer-title">
                <div>
                  <h2>Media information</h2>
                  <p>{current?.name}</p>
                </div>
                <button onClick={() => setPanel("player")}>×</button>
              </div>
              {info ? (
                <div className="info-grid">
                  <Info label="Container" value={info.format} />
                  <Info label="Duration" value={fmt(info.duration)} />
                  <Info
                    label="Resolution"
                    value={
                      info.width && info.height
                        ? `${info.width} × ${info.height}`
                        : "—"
                    }
                  />
                  <Info label="Video" value={info.video_codec || "—"} />
                  <Info label="Audio" value={info.audio_codec || "—"} />
                  <Info
                    label="File size"
                    value={info.size_mb ? `${info.size_mb.toFixed(1)} MB` : "—"}
                  />
                </div>
              ) : (
                <div className="hint">
                  Install FFmpeg/FFprobe to inspect codecs and technical
                  metadata.
                </div>
              )}
              <button className="text-button" onClick={reveal}>
                Show file in folder
              </button>
            </section>
          )}
          {panel === "settings" && (
            <section className="drawer">
              <div className="drawer-title">
                <div>
                  <h2>Player settings</h2>
                  <p>Saved automatically on this device</p>
                </div>
                <button onClick={() => setPanel("player")}>×</button>
              </div>
              <div className="setting-list">
                <Toggle
                  label="Remember playback position"
                  detail="Resume unfinished media where you stopped"
                  value={settings.remember}
                  onChange={(v) => setting("remember", v)}
                />
                <Toggle
                  label="Autoplay next item"
                  detail="Continue through the current playlist"
                  value={settings.autoplay}
                  onChange={(v) => setting("autoplay", v)}
                />
                <Toggle
                  label="Hardware acceleration"
                  detail="Use the playback engine's GPU decoding"
                  value={settings.hardware}
                  onChange={(v) => setting("hardware", v)}
                />
                <Toggle
                  label="Always on top"
                  detail="Keep AethexFlow above other windows"
                  value={settings.alwaysOnTop}
                  onChange={(v) => setting("alwaysOnTop", v)}
                />
              </div>
              <div className="shortcuts">
                <b>Keyboard shortcuts</b>
                <span>Space Play/Pause</span>
                <span>← → Seek 10s</span>
                <span>↑ ↓ Volume</span>
                <span>F Fullscreen</span>
                <span>M Mute</span>
                <span>Ctrl+O Open</span>
              </div>
            </section>
          )}
          {panel === "dub" && (
            <section className="drawer dub">
              <div className="drawer-title">
                <div>
                  <h2>
                    AI Dubbing Studio <em>ONLINE LICENSE</em>
                  </h2>
                  <p>
                    Media processing stays local; every export requires secure
                    online authorization.
                  </p>
                </div>
                <div>
                  <button onClick={analyze} disabled={busy || !current}>
                    {busy ? "WORKING…" : "ANALYZE VIDEO"}
                  </button>
                  {analysis && (
                    <button
                      className="primary"
                      onClick={generateDub}
                      disabled={busy}
                    >
                      EXPORT DUB
                    </button>
                  )}
                  <button onClick={() => setPanel("player")}>×</button>
                </div>
              </div>
              <div className="license-card">
                <div>
                  <small>
                    {license.owner
                      ? "AETHEXFLOW OWNER"
                      : license.paid
                        ? "AETHEXFLOW PLUS"
                        : "FREE DUBBING PLAN"}
                  </small>
                  <b>
                    {license.owner
                      ? "Unlimited owner access"
                      : license.paid
                        ? "Subscription active"
                      : `${license.freeRemaining ?? 5} of 5 free exports remaining`}
                  </b>
                  <span>
                    {license.paid
                      ? "Online verification enabled on this device."
                      : "Only successful exports use the free quota."}
                  </span>
                </div>
                {!license.paid && (
                  <div className="activate-box">
                    <button
                      className="buy"
                      onClick={() =>
                        invoke("open_checkout").catch((e) => setMsg(String(e)))
                      }
                    >
                      UPGRADE
                    </button>
                    <input
                      value={licenseKey}
                      onChange={(e) => setLicenseKey(e.target.value)}
                      placeholder="Enter Lemon Squeezy license key"
                    />
                    <button onClick={activate} disabled={licenseBusy}>
                      {licenseBusy ? "VERIFYING…" : "ACTIVATE"}
                    </button>
                  </div>
                )}
              </div>
              <div className="dub-grid">
                <div>
                  <h3>SPEAKER MAP</h3>
                  {speakers.map((s, i) => (
                    <div className="speaker" key={s.id}>
                      <span className="avatar">{i + 1}</span>
                      <div>
                        <b>{s.id}</b>
                        <small>
                          {s.gender} • {Math.round((s.confidence || 0) * 100)}%
                          confidence
                        </small>
                      </div>
                      <select
                        value={s.voice || ""}
                        onChange={(e) =>
                          setSpeakers((x) =>
                            x.map((z, j) =>
                              j === i ? { ...z, voice: e.target.value } : z,
                            ),
                          )
                        }
                      >
                        <option value="">Choose voice</option>
                        {voices.map((v) => (
                          <option value={v.name} key={v.name}>
                            {v.name} · {v.gender}
                          </option>
                        ))}
                      </select>
                    </div>
                  ))}
                  {!speakers.length && (
                    <div className="hint">
                      Open a video and choose Analyze Video. AI setup is
                      required once before first use.
                    </div>
                  )}
                </div>
                <div>
                  <h3>AUDIO TRACKS</h3>
                  {tracks.map((t) => (
                    <button
                      className={"track " + (t.selected ? "active" : "")}
                      key={t.id}
                      onClick={() =>
                        invoke("select_audio_track", { trackId: t.id })
                          .then(() =>
                            setTracks((x) =>
                              x.map((z) => ({ ...z, selected: z.id === t.id })),
                            ),
                          )
                          .catch((e) => setMsg(String(e)))
                      }
                    >
                      <span>{t.selected ? "●" : "○"}</span>
                      <b>{t.name}</b>
                      <em>{t.lang}</em>
                    </button>
                  ))}
                  {!tracks.length && (
                    <div className="hint">
                      Audio tracks appear after a supported video is opened.
                    </div>
                  )}
                  <div className="privacy-note">
                    <b>Private by design</b>
                    <span>
                      Video and audio never upload. The server receives only a
                      hashed device ID and license/job status.
                    </span>
                  </div>
                </div>
              </div>
            </section>
          )}
          <div className="status">
            <span className={busy ? "pulse" : ""}></span>
            <b>{busy ? "Working" : "Ready"}</b>
            <p>{msg}</p>
            <em>{current ? nameOf(current.path) : "No media loaded"}</em>
          </div>
        </main>
      </div>
    </div>
  );
}
function Info({ label, value }) {
  return (
    <div>
      <small>{label}</small>
      <b>{value}</b>
    </div>
  );
}
function Toggle({ label, detail, value, onChange }) {
  return (
    <label className="setting">
      <span>
        <b>{label}</b>
        <small>{detail}</small>
      </span>
      <input
        type="checkbox"
        checked={value}
        onChange={(e) => onChange(e.target.checked)}
      />
      <i></i>
    </label>
  );
}
createRoot(document.getElementById("root")).render(<App />);
