#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use std::{path::{Path, PathBuf}, process::{Command, Stdio}, sync::{Arc, Mutex}};
use sha2::{Digest,Sha256};
use tauri::{AppHandle, Manager, State};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct PlayerState { pub position:f64, pub duration:f64, pub volume:i32, pub paused:bool, pub muted:bool, pub loaded_file:String, pub audio_tracks:Vec<AudioTrack> }
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AudioTrack { pub id:i32, pub name:String, pub lang:String, pub selected:bool }
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Voice { pub name:String, pub gender:String, pub culture:String }
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Speaker { pub id:String, pub gender:String, pub confidence:f32, pub voice:String }
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubtitleCue { pub index:usize, pub start:f64, pub end:f64, pub text:String, pub speaker:Option<String> }
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisResult { pub language:Option<String>, pub segments:Vec<SubtitleCue>, pub speakers:Vec<Speaker> }
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct MediaInfo { pub duration:f64, pub size_mb:f64, pub format:String, pub video_codec:String, pub audio_codec:String, pub width:u64, pub height:u64 }

pub struct AppState { pub state:Arc<Mutex<PlayerState>>, pub mpc:Arc<Mutex<Option<std::process::Child>>>, pub mpc_hwnd:Arc<Mutex<Option<isize>>> }

const LICENSE_API:&str="https://aethexflow.online/.netlify/functions";
const CHECKOUT_URL:&str="https://aethexflow.lemonsqueezy.com/checkout/buy/66545ed9-c92e-4e15-88d9-521ff4c4751";
fn device_id()->String{
    #[cfg(windows)] let raw={let out=Command::new("reg").args(["query",r"HKLM\SOFTWARE\Microsoft\Cryptography","/v","MachineGuid"]).output().ok();format!("{}|{}",out.map(|x|String::from_utf8_lossy(&x.stdout).into_owned()).unwrap_or_default(),std::env::var("COMPUTERNAME").unwrap_or_default())};
    #[cfg(not(windows))] let raw=format!("{}|{}",std::env::var("HOSTNAME").unwrap_or_default(),std::env::consts::OS);
    format!("{:x}",Sha256::digest(format!("AethexFlow-v3|{raw}").as_bytes()))
}
async fn license_post(path:&str,extra:serde_json::Value)->Result<serde_json::Value,String>{
    let mut value=extra;if let Some(o)=value.as_object_mut(){o.insert("deviceId".into(),serde_json::Value::String(device_id()));}
    let r=reqwest::Client::new().post(format!("{LICENSE_API}/{path}")).json(&value).send().await.map_err(|_|"Internet connection is required for AI Dubbing.".to_string())?;
    let status=r.status();let v:serde_json::Value=r.json().await.map_err(|e|e.to_string())?;if !status.is_success(){return Err(v["error"].as_str().unwrap_or("License verification failed").to_string())}Ok(v)
}
#[tauri::command] pub async fn license_status()->Result<serde_json::Value,String>{license_post("license-status",serde_json::json!({})).await}
#[tauri::command] pub async fn activate_license(license_key:String)->Result<serde_json::Value,String>{if license_key.trim().len()<8{return Err("Enter a valid Lemon Squeezy license key.".into())}license_post("license-activate",serde_json::json!({"licenseKey":license_key.trim()})).await}
#[tauri::command] pub async fn authorize_dub()->Result<serde_json::Value,String>{license_post("dub-authorize",serde_json::json!({})).await}
#[tauri::command] pub async fn complete_dub(job_token:String)->Result<serde_json::Value,String>{license_post("dub-complete",serde_json::json!({"jobToken":job_token})).await}
#[tauri::command] pub async fn open_checkout()->Result<(),String>{
    #[cfg(windows)] { Command::new("cmd").args(["/C","start","",CHECKOUT_URL]).spawn().map_err(|e|e.to_string())?; }
    #[cfg(not(windows))] { Command::new("xdg-open").arg(CHECKOUT_URL).spawn().map_err(|e|e.to_string())?; }
    Ok(())
}

fn find_mpc(app:&AppHandle)->Option<PathBuf> {
    let mut v=Vec::<PathBuf>::new();
    if let Ok(r)=app.path().resource_dir(){ v.push(r.join("mpc-be").join("mpc-be64.exe")); }
    if let Ok(p)=std::env::var("AETHEXFLOW_MPC"){ v.insert(0,PathBuf::from(p)); }
    if let Ok(p)=std::env::var("PROGRAMFILES"){ v.push(PathBuf::from(p).join("MPC-BE/mpc-be64.exe")); }
    v.into_iter().find(|p|p.exists())
}

#[cfg(windows)]
fn find_mpc_hwnd()->Option<isize>{
    use windows::Win32::UI::WindowsAndMessaging::FindWindowW;
    use windows::core::PCWSTR;
    for class in ["MediaPlayerClassicW","MPC-BE"] {
        let w:Vec<u16>=class.encode_utf16().chain(std::iter::once(0)).collect();
        let h=unsafe{FindWindowW(PCWSTR(w.as_ptr()),PCWSTR::null())};
        if !h.is_invalid(){return Some(h.0 as isize)}
    }
    None
}

#[cfg(windows)]
fn send_mpc(hwnd:isize,code:u32,param:&str)->Result<(),String>{
    use std::ffi::OsStr; use std::os::windows::ffi::OsStrExt;
    use windows::Win32::Foundation::{HWND, LPARAM, WPARAM};
    use windows::Win32::UI::WindowsAndMessaging::{COPYDATASTRUCT, SendMessageW, WM_COPYDATA};
    let wide:Vec<u16>=OsStr::new(param).encode_wide().chain(std::iter::once(0)).collect();
    let cds=COPYDATASTRUCT{dwData:code as usize,cbData:(wide.len()*2) as u32,lpData:wide.as_ptr() as *const _};
    unsafe{SendMessageW(HWND(hwnd as _),WM_COPYDATA,WPARAM(0),LPARAM(&cds as *const _ as isize));}
    Ok(())
}
#[cfg(not(windows))] fn send_mpc(_hwnd:isize,_code:u32,_param:&str)->Result<(),String>{Err("Windows only".into())}

#[cfg(windows)]
fn embed_mpc_window(mpc:isize,parent:isize,x:i32,y:i32,w:i32,h:i32)->Result<(),String>{
    use windows::Win32::Foundation::HWND;
    use windows::Win32::UI::WindowsAndMessaging::{SetParent,SetWindowLongW,SetWindowPos,ShowWindow,GWL_STYLE,SWP_NOACTIVATE,SWP_NOZORDER,SW_SHOW,WS_CHILD,WS_VISIBLE};
    let mh=HWND(mpc as _); let ph=HWND(parent as _);
    unsafe{
        SetParent(mh,Some(ph)).map_err(|e|e.to_string())?;
        let mut style=SetWindowLongW(mh,GWL_STYLE,((WS_CHILD|WS_VISIBLE).0) as i32);
        let _=&mut style;
        SetWindowPos(mh,Some(HWND::default()),x,y,w,h,SWP_NOZORDER|SWP_NOACTIVATE).map_err(|e|e.to_string())?;
        ShowWindow(mh,SW_SHOW);
    }
    Ok(())
}
#[cfg(not(windows))] fn embed_mpc_window(_mpc:isize,_parent:isize,_x:i32,_y:i32,_w:i32,_h:i32)->Result<(),String>{Err("Windows only".into())}

#[tauri::command]
pub async fn locate_mpc(app:AppHandle)->Result<String,String>{find_mpc(&app).map(|p|p.to_string_lossy().into_owned()).ok_or_else(||"Bundled MPC-BE was not found.".into())}

#[tauri::command]
pub async fn launch_mpc(file_path:String,app:AppHandle,state:State<'_,AppState>)->Result<String,String>{
    if !Path::new(&file_path).exists(){return Err("Media file not found.".into())}
    let exe=find_mpc(&app).ok_or("Bundled MPC-BE was not found.")?;
    if let Some(mut c)=state.mpc.lock().unwrap().take(){let _=c.kill();}
    let child=Command::new(&exe).arg("/new").arg("/play").arg(&file_path).stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).spawn().map_err(|e|e.to_string())?;
    *state.mpc.lock().unwrap()=Some(child);
    state.state.lock().unwrap().loaded_file=file_path.clone(); state.state.lock().unwrap().paused=false;
    for _ in 0..50 { if let Some(h)=find_mpc_hwnd(){*state.mpc_hwnd.lock().unwrap()=Some(h); break;} tokio::time::sleep(std::time::Duration::from_millis(80)).await; }
    Ok(file_path)
}

#[tauri::command]
pub async fn embed_mpc(app:AppHandle,x:i32,y:i32,w:i32,h:i32,state:State<'_,AppState>)->Result<(),String>{
    let mpc=state.mpc_hwnd.lock().unwrap().ok_or("MPC-BE window not ready")?;
    let parent=app.get_webview_window("main").ok_or("Main window not found")?.hwnd().map_err(|e|e.to_string())?;
    embed_mpc_window(mpc,parent.0 as isize,x,y,w,h)
}

#[tauri::command]
pub async fn resize_mpc(app:AppHandle,x:i32,y:i32,w:i32,h:i32,state:State<'_,AppState>)->Result<(),String>{
    let mpc=state.mpc_hwnd.lock().unwrap().ok_or("MPC-BE window not ready")?;
    let parent=app.get_webview_window("main").ok_or("Main window not found")?.hwnd().map_err(|e|e.to_string())?;
    embed_mpc_window(mpc,parent.0 as isize,x,y,w,h)
}

#[tauri::command]
pub async fn mpc_command(code:u32,param:String,state:State<'_,AppState>)->Result<(),String>{
    let hwnd=state.mpc_hwnd.lock().unwrap().or_else(||find_mpc_hwnd()).ok_or("MPC-BE window not found.")?;
    send_mpc(hwnd,code,&param)
}
#[tauri::command] pub async fn select_audio_track(track_id:i32,state:State<'_,AppState>)->Result<(),String>{mpc_command(0xA0002004,track_id.to_string(),state).await}
#[tauri::command] pub async fn play_pause(state:State<'_,AppState>)->Result<(),String>{mpc_command(0xA0000003,String::new(),state).await}
#[tauri::command] pub async fn seek_to(seconds:f64,state:State<'_,AppState>)->Result<(),String>{mpc_command(0xA0002000,seconds.to_string(),state).await}
#[tauri::command] pub async fn set_speed(speed:f64,state:State<'_,AppState>)->Result<(),String>{mpc_command(0xA0004008,speed.to_string(),state).await}
#[tauri::command] pub async fn toggle_fullscreen(state:State<'_,AppState>)->Result<(),String>{mpc_command(0xA0004000,String::new(),state).await}
#[tauri::command] pub async fn set_volume(volume:i32,state:State<'_,AppState>)->Result<(),String>{mpc_command(0xA0004004,volume.clamp(0,100).to_string(),state).await}
#[tauri::command] pub async fn load_subtitle(file_path:String,state:State<'_,AppState>)->Result<(),String>{if !Path::new(&file_path).exists(){return Err("Subtitle file not found".into())}mpc_command(0xA0002001,file_path,state).await}
#[tauri::command] pub async fn take_screenshot(output_path:String,state:State<'_,AppState>)->Result<(),String>{mpc_command(0xA0004003,output_path,state).await}

#[tauri::command]
pub async fn set_always_on_top(value:bool,app:AppHandle)->Result<(),String>{
    app.get_webview_window("main").ok_or("Main window not found")?.set_always_on_top(value).map_err(|e|e.to_string())
}

#[tauri::command]
pub async fn reveal_file(file_path:String)->Result<(),String>{
    if !Path::new(&file_path).exists(){return Err("Media file not found".into())}
    #[cfg(windows)] { Command::new("explorer").arg("/select,").arg(&file_path).spawn().map_err(|e|e.to_string())?; }
    #[cfg(not(windows))] { let parent=Path::new(&file_path).parent().ok_or("Parent folder not found")?; Command::new("xdg-open").arg(parent).spawn().map_err(|e|e.to_string())?; }
    Ok(())
}

fn collect_media(dir:&Path,out:&mut Vec<String>){
    if out.len()>=10000{return}
    if let Ok(entries)=std::fs::read_dir(dir){for e in entries.flatten(){let p=e.path();if p.is_dir(){collect_media(&p,out)}else if let Some(ext)=p.extension().and_then(|x|x.to_str()){let e=ext.to_ascii_lowercase();if ["mp4","mkv","webm","avi","mov","m4v","wmv","flv","ts","m2ts","3gp","mpeg","mpg","vob","ogv","mp3","flac","wav","aac","m4a","ogg","opus","wma"].contains(&e.as_str()){out.push(p.to_string_lossy().into_owned())}}}}
}
#[tauri::command]
pub async fn scan_media_folder(folder_path:String)->Result<Vec<String>,String>{let p=Path::new(&folder_path);if !p.is_dir(){return Err("Folder not found".into())}let mut out=vec![];collect_media(p,&mut out);out.sort_by_key(|a|a.to_lowercase());Ok(out)}

#[tauri::command]
pub async fn installed_voices()->Result<Vec<Voice>,String>{
    #[cfg(windows)] { let out=Command::new("powershell").args(["-NoProfile","-Command","Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices() | ForEach-Object { $v=$_.VoiceInfo; \"$($v.Name)|$($v.Gender)|$($v.Culture)\" }"]).output().map_err(|e|e.to_string())?; let s=String::from_utf8_lossy(&out.stdout); Ok(s.lines().filter_map(|l|{let p:Vec<_>=l.split('|').collect();if p.len()>=3{Some(Voice{name:p[0].into(),gender:p[1].into(),culture:p[2].into()})}else{None}}).collect()) }
    #[cfg(not(windows))] {Ok(vec![])}
}

#[tauri::command]
pub async fn tts(text:String,voice:String,output_file:String)->Result<String,String>{
    #[cfg(windows)] { let safe=text.replace("'","''"); let v=voice.replace("'","''"); let o=output_file.replace("'","''"); let script=format!("Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.SelectVoice('{}'); $s.SetOutputToWaveFile('{}'); $s.Speak('{}'); $s.Dispose()",v,o,safe); let out=Command::new("powershell").args(["-NoProfile","-Command",&script]).output().map_err(|e|e.to_string())?; if out.status.success(){Ok(output_file)}else{Err(String::from_utf8_lossy(&out.stderr).into())} }
    #[cfg(not(windows))] {let _=(text,voice,output_file);Err("Windows SAPI is only available on Windows.".into())}
}

fn ffmpeg_path(app:&AppHandle)->Option<PathBuf>{
    if let Ok(r)=app.path().resource_dir(){let p=r.join("ffmpeg").join("bin").join("ffmpeg.exe");if p.exists(){return Some(p)} let p=r.join("resources").join("ffmpeg").join("bin").join("ffmpeg.exe");if p.exists(){return Some(p)}}
    if let Ok(p)=std::env::var("AETHEXFLOW_FFMPEG"){let p=PathBuf::from(p);if p.exists(){return Some(p)}}
    if let Ok(path)=std::env::var("PATH"){for dir in std::env::split_paths(&path){let p=dir.join("ffmpeg.exe");if p.exists(){return Some(p)}}}
    None
}
fn ffprobe_path(app:&AppHandle)->Option<PathBuf>{
    if let Ok(r)=app.path().resource_dir(){let p=r.join("ffmpeg").join("bin").join("ffprobe.exe");if p.exists(){return Some(p)} let p=r.join("resources").join("ffmpeg").join("bin").join("ffprobe.exe");if p.exists(){return Some(p)}}
    if let Ok(p)=std::env::var("AETHEXFLOW_FFPROBE"){let p=PathBuf::from(p);if p.exists(){return Some(p)}}
    if let Ok(path)=std::env::var("PATH"){for dir in std::env::split_paths(&path){let p=dir.join("ffprobe.exe");if p.exists(){return Some(p)}}}
    None
}

#[tauri::command]
pub async fn ffprobe_tracks(file_path:String,app:AppHandle)->Result<Vec<AudioTrack>,String>{
    let exe=ffprobe_path(&app).ok_or("FFprobe not found. Install FFmpeg or set AETHEXFLOW_FFPROBE.")?;
    let out=Command::new(exe).args(["-v","error","-select_streams","a","-show_entries","stream=index:stream_tags=language,title","-of","json",&file_path]).output().map_err(|e|e.to_string())?;
    if !out.status.success(){return Err(String::from_utf8_lossy(&out.stderr).to_string())}
    let json:serde_json::Value=serde_json::from_slice(&out.stdout).map_err(|e|e.to_string())?; let mut r=vec![];
    if let Some(arr)=json["streams"].as_array(){for (i,x) in arr.iter().enumerate(){let fallback=format!("Audio {}",i+1);let title=x["tags"]["title"].as_str().unwrap_or(&fallback);r.push(AudioTrack{id:i as i32,name:title.into(),lang:x["tags"]["language"].as_str().unwrap_or("und").into(),selected:i==0});}}
    Ok(r)
}

#[tauri::command]
pub async fn media_info(file_path:String,app:AppHandle)->Result<MediaInfo,String>{
    let exe=ffprobe_path(&app).ok_or("FFprobe not found. Install FFmpeg or set AETHEXFLOW_FFPROBE.")?;
    let out=Command::new(exe).args(["-v","error","-show_entries","format=duration,size,format_name:stream=codec_type,codec_name,width,height","-of","json",&file_path]).output().map_err(|e|e.to_string())?;
    if !out.status.success(){return Err(String::from_utf8_lossy(&out.stderr).to_string())}
    let j:serde_json::Value=serde_json::from_slice(&out.stdout).map_err(|e|e.to_string())?;
    let mut m=MediaInfo::default();m.duration=j["format"]["duration"].as_str().and_then(|v|v.parse().ok()).unwrap_or(0.0);m.size_mb=j["format"]["size"].as_str().and_then(|v|v.parse::<f64>().ok()).unwrap_or(0.0)/1_048_576.0;m.format=j["format"]["format_name"].as_str().unwrap_or("unknown").split(',').next().unwrap_or("unknown").to_uppercase();
    if let Some(streams)=j["streams"].as_array(){for s in streams{match s["codec_type"].as_str(){Some("video") if m.video_codec.is_empty()=>{m.video_codec=s["codec_name"].as_str().unwrap_or("unknown").to_uppercase();m.width=s["width"].as_u64().unwrap_or(0);m.height=s["height"].as_u64().unwrap_or(0)},Some("audio") if m.audio_codec.is_empty()=>m.audio_codec=s["codec_name"].as_str().unwrap_or("unknown").to_uppercase(),_=>{}}}}
    Ok(m)
}

#[tauri::command]
pub async fn mux_dub(video:String,dub_audio:String,output:String,app:AppHandle)->Result<String,String>{
    if !Path::new(&video).exists(){return Err("Video file not found".into())} if !Path::new(&dub_audio).exists(){return Err("Dub audio file not found".into())}
    let ff=ffmpeg_path(&app).ok_or("FFmpeg not found. Install FFmpeg or set AETHEXFLOW_FFMPEG.")?;
    let out=Command::new(ff).args(["-y","-i",&video,"-i",&dub_audio,"-map","0:v?","-map","0:a?","-map","1:a:0","-c:v","copy","-c:a","copy","-metadata:s:a:0","title=Original","-metadata:s:a:1","title=AethexFlow Dub","-shortest",&output]).output().map_err(|e|e.to_string())?;
    if out.status.success(){Ok(output)}else{Err(String::from_utf8_lossy(&out.stderr).into())}
}

fn python_exe(app:&AppHandle)->PathBuf {
    if let Ok(r)=app.path().resource_dir(){
        let portable=r.join("python").join("python.exe");
        if portable.exists(){return portable}
        let bundled=r.join("ai").join(".venv").join("Scripts").join("python.exe");
        if bundled.exists(){return bundled}
        let script=r.join("ai").join("dub_worker.py");
        if script.exists(){
            if let Ok(p)=std::env::var("AETHEXFLOW_PYTHON"){return PathBuf::from(p)}
            if let Ok(p)=which::which("python"){return p}
            return PathBuf::from("python");
        }
    }
    if let Ok(p)=std::env::var("AETHEXFLOW_PYTHON"){return PathBuf::from(p)}
    PathBuf::from("python")
}
fn ai_script(app:&AppHandle)->Result<PathBuf,String>{
    let r=app.path().resource_dir().map_err(|e|e.to_string())?;
    let p=r.join("ai").join("dub_worker.py");
    if p.exists(){Ok(p)}else{Err("AI worker is missing. Reinstall the AethexFlow AI component.".into())}
}

#[tauri::command]
pub async fn analyze_speakers(file_path:String,app:AppHandle)->Result<AnalysisResult,String>{
    if !Path::new(&file_path).exists(){return Err("File not found".into())}
    let script=ai_script(&app)?;
    let ff=ffmpeg_path(&app).ok_or("Bundled FFmpeg is missing. Reinstall AethexFlow Player.")?;
    let out=Command::new(python_exe(&app)).env("AETHEXFLOW_FFMPEG",ff).args([script.to_string_lossy().as_ref(),"--mode","analyze","--video",&file_path,"--output","-"]).output().map_err(|e|format!("Python AI engine could not start: {e}"))?;
    if !out.status.success(){return Err(String::from_utf8_lossy(&out.stderr).to_string())}
    let raw=String::from_utf8_lossy(&out.stdout);
    serde_json::from_str(raw.trim()).map_err(|e|format!("AI analysis returned invalid data: {e}. Output: {}",raw.chars().take(500).collect::<String>()))
}

#[tauri::command]
pub async fn generate_dub(file_path:String,analysis:AnalysisResult,output_wav:String,job_token:String,app:AppHandle)->Result<String,String>{
    if !Path::new(&file_path).exists(){return Err("Video file not found".into())}
    license_post("dub-verify",serde_json::json!({"jobToken":job_token})).await?;
    let script=ai_script(&app)?;
    let ff=ffmpeg_path(&app).ok_or("Bundled FFmpeg is missing. Reinstall AethexFlow Player.")?;
    let td=std::env::temp_dir().join(format!("aethexflow-analysis-{}.json",std::process::id()));
    std::fs::write(&td,serde_json::to_vec(&analysis).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
    let out=Command::new(python_exe(&app)).env("AETHEXFLOW_FFMPEG",ff).args([script.to_string_lossy().as_ref(),"--mode","dub","--video",&file_path,"--analysis",td.to_string_lossy().as_ref(),"--output",&output_wav]).output().map_err(|e|e.to_string())?;
    let _=std::fs::remove_file(&td);
    if out.status.success(){Ok(output_wav)}else{Err({ let e=String::from_utf8_lossy(&out.stderr).to_string(); if e.trim().is_empty(){String::from_utf8_lossy(&out.stdout).to_string()}else{e} })}
}

#[tauri::command]
pub async fn stop_mpc(state:State<'_,AppState>)->Result<(),String>{if let Some(mut c)=state.mpc.lock().unwrap().take(){let _=c.kill();}*state.mpc_hwnd.lock().unwrap()=None;Ok(())}

pub fn run(){
    let state=AppState{state:Arc::new(Mutex::new(PlayerState::default())),mpc:Arc::new(Mutex::new(None)),mpc_hwnd:Arc::new(Mutex::new(None))};
    tauri::Builder::default().plugin(tauri_plugin_dialog::init()).manage(state).invoke_handler(tauri::generate_handler![license_status,activate_license,authorize_dub,complete_dub,open_checkout,locate_mpc,launch_mpc,embed_mpc,resize_mpc,mpc_command,select_audio_track,play_pause,seek_to,set_speed,set_volume,toggle_fullscreen,load_subtitle,take_screenshot,set_always_on_top,reveal_file,scan_media_folder,installed_voices,tts,ffprobe_tracks,media_info,mux_dub,analyze_speakers,generate_dub,stop_mpc]).run(tauri::generate_context!()).expect("AethexFlow failed");
}
