from pathlib import Path
import json, hashlib, re, sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]
def ok(cond,msg):
    print(('PASS' if cond else 'FAIL')+' - '+msg)
    if not cond: errors.append(msg)
required=['package.json','package-lock.json','src-tauri/tauri.conf.json','src-tauri/Cargo.toml','src-tauri/src/main.rs','src-tauri/src/lib.rs','src-tauri/icons/icon.ico','src-tauri/resources/mpc-be/mpc-be64.exe','src-tauri/resources/mpc-be/LICENSE.txt','ai/dub_worker.py','BUILD-FINAL-INNO.ps1','installer/AethexFlowPlayer.iss']
for rel in required: ok((ROOT/rel).exists(),f'Required file: {rel}')
for rel in ['package.json','src-tauri/tauri.conf.json','src-tauri/capabilities/default.json']:
    try: json.loads((ROOT/rel).read_text(encoding='utf-8')); ok(True,f'JSON parse: {rel}')
    except Exception as e: ok(False,f'JSON parse: {rel}: {e}')
lib=(ROOT/'src-tauri/src/lib.rs').read_text(encoding='utf-8',errors='ignore')
cmds=re.findall(r'#\[tauri::command\]\s*(?:pub\s+)?(?:async\s+)?fn\s+([A-Za-z0-9_]+)',lib)
ok(len(cmds)==len(set(cmds)),f'Tauri commands unique ({len(cmds)})')
m=re.search(r'generate_handler!\s*\[(.*?)\]',lib,re.S)
if m:
    handlers=[x.strip().split('::')[-1] for x in m.group(1).split(',') if x.strip()]
    ok(len(handlers)==len(set(handlers)),f'Handler registrations unique ({len(handlers)})')
    ok(set(handlers)==set(cmds),f'Handler/implementation set matches ({len(handlers)})')
else: ok(False,'generate_handler list found')
mpc=ROOT/'src-tauri/resources/mpc-be/mpc-be64.exe'
if mpc.exists():
    data=mpc.read_bytes(); ok(data[:2]==b'MZ','MPC-BE is a Windows PE executable'); print('INFO - MPC-BE SHA256:',hashlib.sha256(data).hexdigest())
icon=ROOT/'src-tauri/icons/icon.ico'
if icon.exists():
    b=icon.read_bytes(); ok(len(b)>1000 and b[:4]==b'\x00\x00\x01\x00','Windows ICO header valid')
if errors:
    print(f'\nFAILED: {len(errors)} check(s)'); sys.exit(1)
print('\nSTATIC RELEASE PREFLIGHT PASSED')
