from pathlib import Path
import json, re, sys
root = Path(__file__).resolve().parents[1]
errors=[]
def req(p):
    q=root/p
    if not q.exists(): errors.append(f'MISSING: {p}')
    else: print(f'PASS - {p}')
for p in [
    'installer/AethexFlowPlayer.iss',
    'src-tauri/src/main.rs','src-tauri/src/lib.rs','src-tauri/Cargo.toml','src-tauri/tauri.conf.json',
    'src-tauri/icons/icon.ico','src-tauri/resources/mpc-be/mpc-be64.exe',
    'ai/dub_worker.py','ai/requirements.txt','BUILD-FINAL-INNO.ps1'
]: req(p)
iss=(root/'installer/AethexFlowPlayer.iss').read_text(encoding='utf-8')
for token in ['OutputBaseFilename=AethexFlow-Player-Setup','SetupLogging=yes','UninstallDisplayIcon','MicrosoftEdgeWebView2RuntimeInstallerX64.exe','Create a &desktop shortcut']:
    if token not in iss: errors.append(f'INNO TOKEN MISSING: {token}')
    else: print(f'PASS - Inno token: {token}')
conf=json.loads((root/'src-tauri/tauri.conf.json').read_text(encoding='utf-8'))
assert conf['identifier']=='online.aethexflow.player'
print('PASS - Tauri identifier')
if errors:
    print('\n'.join(errors)); sys.exit(1)
print('PASS - Inno release preflight')
