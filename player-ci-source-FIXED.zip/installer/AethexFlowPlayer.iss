#define MyAppName "AethexFlow Player"
#define MyAppVersion "3.0.0"
#define MyAppPublisher "AethexFlow"
#define MyAppURL "https://aethexflow.online"
#define MyAppExeName "aethexflow-player.exe"

[Setup]
AppId={{31F574D0-2BE2-587A-AB65-5841987E36DF}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\AethexFlow Player
DefaultGroupName=AethexFlow Player
AllowNoIcons=yes
OutputDir=..\release
OutputBaseFilename=AethexFlow-Player-Setup
SetupIconFile=..\src-tauri\icons\icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
SetupLogging=yes
VersionInfoVersion=3.0.0.0
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription=AethexFlow Player Offline Installer
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#MyAppVersion}
DisableProgramGroupPage=yes
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "..\stage\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\stage\mpc-be\*"; DestDir: "{app}\mpc-be"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\stage\python\*"; DestDir: "{app}\python"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\stage\ffmpeg\*"; DestDir: "{app}\ffmpeg"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\stage\models\*"; DestDir: "{app}\models"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\stage\ai\*"; DestDir: "{app}\ai"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\stage\THIRD-PARTY-NOTICES.txt"; DestDir: "{app}"; Flags: ignoreversion skipifsourcedoesntexist
Source: "..\stage\redist\MicrosoftEdgeWebView2RuntimeInstallerX64.exe"; DestDir: "{tmp}"; DestName: "AethexFlow-WebView2-Setup.exe"; Flags: deleteafterinstall

[Icons]
Name: "{group}\AethexFlow Player"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall AethexFlow Player"; Filename: "{uninstallexe}"
Name: "{autodesktop}\AethexFlow Player"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{tmp}\AethexFlow-WebView2-Setup.exe"; Parameters: "/silent /install"; StatusMsg: "Ensuring Microsoft Edge WebView2 Runtime is available..."; Flags: runhidden waituntilterminated; Check: not IsWebView2Installed
Filename: "{app}\{#MyAppExeName}"; Description: "Launch AethexFlow Player"; Flags: nowait postinstall skipifsilent

[Code]
function WebViewVersionAt(RootKey: Integer; KeyName: String): Boolean;
var
  Version: String;
begin
  Result := RegQueryStringValue(RootKey, KeyName, 'pv', Version) and (Version <> '') and (Version <> '0.0.0.0');
end;

function IsWebView2Installed: Boolean;
const
  ClientKey = 'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}';
begin
  Result :=
    WebViewVersionAt(HKLM64, ClientKey) or
    WebViewVersionAt(HKLM32, ClientKey) or
    WebViewVersionAt(HKCU, ClientKey);
end;
